//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import static java.lang.System.*;

public class Toy
{
	private String name;
	private int count;

	public Toy()
	{
	}

	public Toy( String nm )
	{
	}
	
	public int getCount()
	{
		return 0;
	}
	
	public void setCount( int cnt )
	{
	}
	
	public String getName()
	{
		return null;
	}
	
	public void setName( String nm )
	{
	}

	public String toString()
	{
	   return "";
	}
}